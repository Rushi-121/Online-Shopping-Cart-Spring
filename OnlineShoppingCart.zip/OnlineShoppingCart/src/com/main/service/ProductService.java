package com.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.dao.ProductDao;
import com.main.model.Product;

@Service
public class ProductService {
	
	private ProductDao productDao;
	
	
	public ProductDao getProductDao() {
		return productDao;
	}
	@Autowired
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	public void addProduct(Product p) {
		productDao.save(p);
		System.out.println("Product Added Successfully.....!");
	}
	
	public  void updateProduct(Product p) {
		productDao.update(p);
		System.out.println("Product Update Successfully......!!");
	}
	
	public void deleteProduct(int id) {
		productDao.delete(id);
		System.out.println("product Deleted Successfully.....!!");
	}
	public void showAllProducts() {
		productDao.getAllProducts().forEach(p->System.out.println("Product ID:"+p.getPid()+"Product name:"+p.getPname()+"Product Desc:"+p.getDescription()+"Product Rating:"+p.getRating()+"Product price:"+p.getPrice()));
	}

}
