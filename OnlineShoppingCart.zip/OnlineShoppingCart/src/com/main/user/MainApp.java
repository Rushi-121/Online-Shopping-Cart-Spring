package com.main.user;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.main.config.Shoppingconfig;
import com.main.model.Product;
import com.main.service.ProductService;

public class MainApp {
	public static void main(String[] args) {
		ApplicationContext ap = new AnnotationConfigApplicationContext(Shoppingconfig.class);
		ProductService ps=ap.getBean(ProductService.class);
		
		Scanner sc= new Scanner(System.in);
		int ch;
		do {
			System.out.println("============Online Shopping cart=============");
			System.out.println("1.Add Product");
			System.out.println("2.View All Product");
			System.out.println("3.Update Product");
			System.out.println("4. Delete Product");
			System.out.println("5.Exit");
			System.out.println("Enter Your Choice");
			ch=sc.nextInt();
			switch(ch) {
			
			case 1:
				Product p= new Product();
				System.out.println("Eneter your Product id:");
				sc.nextLine();
				p.setPid(sc.nextInt());
				System.out.println("Enter Your Product Name:");
				p.setPname(sc.next());
				sc.nextLine();
				System.out.println("Enter Product Description:");
				p.setDescription(sc.nextLine());
				System.out.println("Enter the Product Rating:");
				p.setRating(sc.nextFloat());
				System.out.println("Enter the Product Price:");
				p.setPrice(sc.nextInt());
				ps.addProduct(p);
				break;
				
			case 2:
				ps.showAllProducts();
				break;
			case 3:
				Product up = new Product();
                System.out.print("Enter Product ID: ");
                up.setPid(sc.nextInt());
                System.out.print("Enter New Name: ");
                sc.nextLine();
                up.setPname(sc.nextLine());
                System.out.println("Enter You Want to New Description:");
                up.setDescription(sc.nextLine());
                System.out.println("Enter Product Ratings");
                up.setRating(sc.nextFloat());
                System.out.println("Enter the new price of Product:");
                up.setPrice(sc.nextInt());
                ps.updateProduct(up);
                break;
			case 4:
				 System.out.print("Enter Product ID to Delete: ");
                 int id = sc.nextInt();
				ps.deleteProduct(id);
				break;
			case 5:
                System.out.println("Thank You!");
                break;

            default:
                System.out.println("Invalid Choice");
			}
			
		}while(ch!=5);
	}

}
