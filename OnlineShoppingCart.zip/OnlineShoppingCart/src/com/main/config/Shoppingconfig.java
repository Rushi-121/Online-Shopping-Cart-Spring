package com.main.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages = "com.main")
public class Shoppingconfig {
	@Bean
	public DriverManagerDataSource datasourse() {
		DriverManagerDataSource ds=new DriverManagerDataSource();
		ds.setDriverClassName("com.mysql.cj.jdbc.Driver");
		ds.setUrl("jdbc:mysql://localhost:3306/shoppingdb");
		ds.setUsername("root");
		ds.setPassword("root");
		return ds;
	}
	@Bean
	public JdbcTemplate template() {
		return new JdbcTemplate(datasourse());	
	}

}
