package com.main.dao;

import java.util.List;

import com.main.model.Product;

public interface ProductDao {
	//Create
	 int save(Product product);
	
	//Update
	int update(Product product);
	//Delete
	void delete(int id);
	//Read Single
	//Product getById(int id);
	//Read All
	List<Product>getAllProducts();

}
