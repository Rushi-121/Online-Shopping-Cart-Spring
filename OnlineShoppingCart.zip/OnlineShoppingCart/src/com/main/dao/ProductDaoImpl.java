package com.main.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.main.model.Product;
@Repository
public class ProductDaoImpl implements ProductDao {
	@Autowired
	private JdbcTemplate template;
	Scanner sc =new Scanner(System.in);

	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	@Override
	public int save(Product product) {
		 String sql = "INSERT INTO product (pid, pname, description, rating, price) VALUES (?, ?, ?, ?, ?)";
		 return template.update(sql,product.getPid(),product.getPname(),product.getDescription(),product.getRating(),product.getPrice());
	}
	@Override
	public int update(Product product) {
		String sql = "UPDATE product SET pname=?, description=?, rating=?, price=? WHERE pid=?";
		 return template.update(sql,product.getPname(),product.getDescription(),product.getRating(),product.getPrice(),product.getPid());
	}
	@Override
	public void delete(int id) {
		
		
		String sql="delete from product where pid=?";
		 template.update(sql,id);
	}
	
	@Override
	public List<Product> getAllProducts() {
		String sql="Select *from product";
		
		return template.query(sql, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			Product p= new Product();
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setDescription(rs.getString(3));
			p.setRating(rs.getFloat(4));
			p.setPrice(rs.getInt(5));
				return p;
			}
		});
		
	}
	

}
